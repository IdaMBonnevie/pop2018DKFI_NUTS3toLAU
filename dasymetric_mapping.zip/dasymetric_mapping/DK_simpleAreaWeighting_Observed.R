# This code calculates 2018 population at municipality level
# for Denmark using simple area weighting 
# and it outputs observed 2018 values at municipality level (LAU) 

# Install and import libraries: 
#install.packages("areal")
library(areal)
#install.packages("classInt")
library(classInt)
##install.packages("eurostat")
library(eurostat)
##install.packages("dplyr")
library(dplyr)
####install.packages("Metrics")
library(Metrics)
##install.packages("rstudioapi")
library(rstudioapi)
##install.packages("sf")
library(sf)
##install.packages("tmap")
library(tmap)

# Set directory to script directory: 
script_directory <- dirname(rstudioapi::getSourceEditorContext()$path)
setwd(script_directory)

# Set proper visualisation of numeric values
options(scipen = 100, digits = 4) # can be reset by options(scipen=0)

# Define colorpalette default: 
colors_default <- colorRampPalette(c("#FFFF00", "#990000"))  


###FUNCTIONS:

# DEFINE Function to make classification break values: 
make_equal_interval <- function(dataset_column_input, amount_intervals, style_type, rounded) {
  # Classify data using n intervals with the style method
  classifications <- classIntervals(dataset_column_input, n = amount_intervals, style = style_type)
  print(style_type)
  print(classifications)
  # Extract the breaks
  breaks <- classifications$brks
  print(breaks)
  # Calculate frequencies of data in each class
  frequencies <- tabulate(findInterval(dataset_column_input, breaks, rightmost.closed = TRUE))
  # Find breaks that result in non-empty classes
  non_empty_breaks <- breaks[frequencies > 0]
  # Round the breaks to divisible by 10 if rounded = TRUE otherwise round to three decimals after comma:
  if (rounded == TRUE) {
    non_empty_breaks <- round(non_empty_breaks, digits = -1)
  } else {
    non_empty_breaks <- round(non_empty_breaks, digits = 3)
  } 
  print(non_empty_breaks)
  # Add min(dataset_column_input) if lower than min(non_empty_breaks)
  if (min(dataset_column_input) < min(non_empty_breaks)) {
    non_empty_breaks[non_empty_breaks == min(non_empty_breaks)] <- min(dataset_column_input)
  }
  # Add max(dataset_column_input) if higher than max(non_empty_breaks)
  if (max(dataset_column_input) > max(non_empty_breaks)) {
    non_empty_breaks[non_empty_breaks == max(non_empty_breaks)] <- max(dataset_column_input)
  }
  non_empty_breaks <- sort(unique(non_empty_breaks))
  print(non_empty_breaks)
  return(non_empty_breaks)}

# DEFINE Function to create bbox: 
create_bbox <- function(dataset_input, justXmin, justXmax, justYmin, justYmax) {
  bbox_new <- st_bbox(dataset_input)
  xrange <- bbox_new$xmax - bbox_new$xmin # range of x values
  yrange <- bbox_new$ymax - bbox_new$ymin # range of y values
  bbox_new[1] <- (bbox_new[1] - (justXmin * xrange)) # xmin - left
  bbox_new[3] <- bbox_new[3] + (justXmax * xrange) # xmax - right
  bbox_new[2] <- bbox_new[2] - (justYmin * yrange) # ymin - bottom
  bbox_new[4] <- bbox_new[4] + (justYmax * yrange) # ymax - top
  bbox_new <- bbox_new %>%  # take the bounding box ...
    st_as_sfc() # ... and make it a sf polygon
  return(bbox_new)}


###DATA: 

## 1) POPULATION AT NUTS
#Get NUTS3 shapes using eurostat
nuts3_all <- get_eurostat_geospatial(
  output_class = "sf",
  resolution = "01",
  nuts_level = "3",
  year = "2016",
  crs = "3035"
)

# Filter the dataset where CNTR_CODE == "DK"
nuts3_DK <- nuts3_all %>% #Simple feature collection with 11 features and 11 fields
  filter(CNTR_CODE == "DK")

## Get Eurostat population table
#freq: #unique(poptable$freq) "A" 
#sex: #unique(poptable$sex) "F" "M" "T"
#unit #unique(poptable$unit) "NR" :number;unitOfMeasure
#age #unique(poptable$age) "TOTAL"  "UNK"    "Y10-14" "Y15-19"...
#geo #unique(poptable$geo) 
#TIME_PERIOD: 2018-01-01 
#values: population 
poptable <- get_eurostat("demo_r_pjangrp3") %>%  
  filter(TIME_PERIOD == "2018-01-01",
         nchar(geo)==5, 
         sex == "T",
         age == "TOTAL")

#Get NUTS3 pop for only DK: 
poptable_DK <- poptable[grep("^DK", poptable$geo), ]

## Get target data: NUTS3 population spatial data through merge: 
nuts3pop <- nuts3_DK %>%
  left_join(poptable_DK, by = c("NUTS_ID" = "geo")) 
#NUTS_ID is NUTS ID in the gisco spatial dataset
#geo is NUTS ID in the Eurostat table

# Set spatial extent DK
analysis_spatial_extent_DK <- st_union(nuts3_DK)

## 2) LAU POP 2018  
#full Europe
LAUpop2018 <- st_read("data/LAU_RG_01M_2018_3035.shp")
#Clip LAU pop using computed extents
LAUpop2018 <- st_intersection(LAUpop2018, analysis_spatial_extent_DK)


############## DASYMETRIC REFINEMENT ANALYSIS: 
# aw_interpolate to interpolate to LAU level: 
estimated_lau_pop <- aw_interpolate(
  .data = LAUpop2018, #referred to as target elsewhere
  tid = "LAU_ID", #id column in target
  source = nuts3pop,
  sid = "NUTS_ID", #id column in source
  weight = "sum", #should be sum for intensive vs. extensive interpolations
  output = "sf",
  extensive = "values" #attribute in source to interpolate 
)

# replace NA with 0 in estimated pop
estimated_lau_pop$values[is.na(estimated_lau_pop$values)] <- 0

# Calculate percentage overestimation (marked with plus) or underestimation (marked with minus) of estimated population 
estimated_lau_pop$pop2018dif <- ((-(estimated_lau_pop$POP_2018 - as.numeric(estimated_lau_pop$values)) / estimated_lau_pop$POP_2018) *100.)

#Check geometries
st_geometry_type(estimated_lau_pop)
# Keep only POLYGON and MULTIPOLYGON geometries
estimated_lau_pop <- estimated_lau_pop[st_geometry_type(estimated_lau_pop) %in% c("POLYGON", "MULTIPOLYGON"), ]
estimated_lau_pop <- st_collection_extract(estimated_lau_pop, "POLYGON")
estimated_lau_pop <- st_cast(estimated_lau_pop, "MULTIPOLYGON")

# KEY DENSITY COLUMN: estimated LAU population density in km2:  
estimated_lau_pop$densKm2Est <- as.numeric(estimated_lau_pop$values) / estimated_lau_pop$AREA_KM2 

#### MAP OUTPUT: SIMPLE AREA INTERPOLATION FOR DENMARK 
#quantile: 
rounded_breaks <- c(15.23, 40.00, 60.00, 80.00, 110.00, 150.00, 380.00, 870.00, 11981.55)
# breakvalues: Replace with min if lower than min(rounded_breaks)
if (min(estimated_lau_pop$densKm2Est) < min(rounded_breaks)) {
  rounded_breaks[[1]] <- min(estimated_lau_pop$densKm2Est)
}
# Add max if higher than max(rounded_breaks)
if (max(estimated_lau_pop$densKm2Est) > max(rounded_breaks)) {
  rounded_breaks[[length(rounded_breaks)]] <- max(estimated_lau_pop$densKm2Est)
}
# TMAP: Estimated population density    
# Bbox of main map: 
bbox_main <- create_bbox(estimated_lau_pop, 0., -0.2, 0., 0.15)
# Plot Denmark without Bornholm:
map_DensEst_main <- tm_shape(estimated_lau_pop, bbox = bbox_main) +
  tm_polygons(col = "densKm2Est", 
              title = "People per km2\n(2018, estimated)",
              breaks = rounded_breaks, 
              palette = c("#FDFD63", "#990000")) + 
  tm_layout(bg.color = "#E1EEF2",
            legend.position = c("right", "top"),
            legend.bg.color = "white",
            title= "Simple area interpolation\nfor Denmark",
            legend.title.size = 1.,
            title.position = c("left", "top"),
            legend.frame = "grey60") + 
  tm_compass(type = "arrow", 
             position = c("left", "top")) + 
  tm_scale_bar(position = c("left", "bottom"), #c("right", "center"), #
               #width = 0.35,
               text.size = 1.5) 
               #breaks = c(0, 25, 50, 75, 100)) +  # Place in bottom-left
  #tm_layout(outer.margins = c(0, 0, 0.1, 0))
print(map_DensEst_main)
# Plot Bornholm map on top: 
bbox_Bornholm <- create_bbox(estimated_lau_pop, -0.92, 0.01, -0.14, -0.72)
map_DensEst_Born <- tm_shape(estimated_lau_pop, bbox = bbox_Bornholm) +
  tm_polygons(col = "densKm2Est", 
              legend.show = FALSE,
              breaks = rounded_breaks, 
              palette = c("#FDFD63", "#990000")) + 
  tm_layout(frame = "grey60", 
            bg.color = "#D6EBF2" 
  )
print(map_DensEst_Born, 
      vp = grid::viewport(x = 0.705, y = 0.14,
                          width = 0.2, 
                          height = 0.2)
)

#Check geometries
st_geometry_type(LAUpop2018)
# Keep only POLYGON and MULTIPOLYGON geometries
LAUpop2018 <- LAUpop2018[st_geometry_type(estimated_lau_pop) %in% c("POLYGON", "MULTIPOLYGON"), ]
LAUpop2018 <- st_collection_extract(estimated_lau_pop, "POLYGON")
LAUpop2018 <- st_cast(estimated_lau_pop, "MULTIPOLYGON")

#### MAP OUTPUT: OBSERVED POPULATION DENSITY FOR DENMARK 
# quantile: 
rounded_breaks <- make_equal_interval(as.numeric(LAUpop2018$POP_DENS_2), 8, "quantile", rounded = TRUE) # breakvalues
# TMAP: OBSERVED population density    
# Bbox of main map: 
bbox_main <- create_bbox(LAUpop2018, 0., -0.2, 0., 0.15)
# Plot Denmark without Bornholm:
map_Dens_main <- tm_shape(LAUpop2018, bbox = bbox_main) +
  tm_polygons(col = "POP_DENS_2", 
              title = "People per km2\n(LAU 2018)",
              breaks = rounded_breaks, 
              palette = c("#FDFD63", "#990000"), 
              border.col = "transparent") + 
  tm_layout(bg.color = "#E1EEF2",
            legend.position = c("right", "top"),
            legend.bg.color = "white",
            title= "Population observed\nat municipality level",
            legend.title.size = 1.,
            title.position = c("left", "top"),
            legend.frame = "grey60") + 
  tm_compass(type = "arrow", 
             position = c("right", "center")) + 
  tm_scale_bar(position = c("left", "bottom"), 
               text.size = 1.5) 
print(map_Dens_main)
# Plot Bornholm map on top: 
bbox_Bornholm <- create_bbox(LAUpop2018, -0.92, 0.01, -0.14, -0.72)
map_Dens_Born <- tm_shape(LAUpop2018, bbox = bbox_Bornholm) +
  tm_polygons(col = "POP_DENS_2", 
              legend.show = FALSE,
              breaks = rounded_breaks, 
              palette = c("#FDFD63", "#990000")) + 
  tm_layout(frame = "grey60", 
            bg.color = "#D6EBF2" 
  )
print(map_Dens_Born, 
      vp = grid::viewport(x = 0.705, y = 0.14,
                          width = 0.2, 
                          height = 0.2)
)

############## PRINT STATEMENTS ##############
######---------> PRINT
cat("Overall percentage error:", sum(abs(estimated_lau_pop$pop2018dif)))
cat("Overall percentage error average:", sum(estimated_lau_pop$pop2018dif))
cat("Mean signed deviation or Bias:", bias(estimated_lau_pop$POP_2018, as.numeric(estimated_lau_pop$values)))
cat("Mean absolute error:", mae(estimated_lau_pop$POP_2018, as.numeric(estimated_lau_pop$values)))
cat("Median absolute error:", mdae(estimated_lau_pop$POP_2018, as.numeric(estimated_lau_pop$values)))
cat("Mean squared error:", mse(estimated_lau_pop$POP_2018, as.numeric(estimated_lau_pop$values)))
cat("Root mean squared error:", rmse(estimated_lau_pop$POP_2018, as.numeric(estimated_lau_pop$values)))
cat("Mean absolute percentage error:", mape(estimated_lau_pop$POP_2018, as.numeric(estimated_lau_pop$values)))
