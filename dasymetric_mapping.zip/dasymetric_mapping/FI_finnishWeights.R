# This code calculates 2018 population at municipality level
# and an error map 
# for Finland using Finnish weights and CORINE 2018 land cover for dasymetric refinement 

# Install and import libraries: 
#install.packages("areal")
library(areal)
#install.packages("classInt")
library(classInt)
##install.packages("eurostat")
library(eurostat)
##install.packages("dplyr")
library(dplyr)
####install.packages("Metrics")
library(Metrics)
##install.packages("rstudioapi")
library(rstudioapi)
##install.packages("sf")
library(sf)
##install.packages("tmap")
library(tmap)
##install.packages("units")
library(units)

# Set directory to script directory: 
script_directory <- dirname(rstudioapi::getSourceEditorContext()$path)
setwd(script_directory)

# Set proper visualisation of numeric values
options(scipen = 100, digits = 4) # can be reset by options(scipen=0)

# Define colorpalette default: 
colors_default <- colorRampPalette(c("#FFFF00", "#990000"))  


###FUNCTIONS:

# DEFINE Function to make classification break values: 
make_equal_interval <- function(dataset_column_input, amount_intervals, style_type, rounded) {
  # Classify data using n intervals with the style method
  classifications <- classIntervals(dataset_column_input, n = amount_intervals, style = style_type)
  print(style_type)
  print(classifications)
  # Extract the breaks
  breaks <- classifications$brks
  print(breaks)
  # Calculate frequencies of data in each class
  frequencies <- tabulate(findInterval(dataset_column_input, breaks, rightmost.closed = TRUE))
  # Find breaks that result in non-empty classes
  non_empty_breaks <- breaks[frequencies > 0]
  # Round the breaks to divisible by 10 if rounded = TRUE otherwise round to three decimals after comma:
  if (rounded == TRUE) {
    non_empty_breaks <- round(non_empty_breaks, digits = -1)
  } else {
    non_empty_breaks <- round(non_empty_breaks, digits = 3)
  } 
  print(non_empty_breaks)
  # Add min(dataset_column_input) if lower than min(non_empty_breaks)
  if (min(dataset_column_input) < min(non_empty_breaks)) {
    non_empty_breaks[non_empty_breaks == min(non_empty_breaks)] <- min(dataset_column_input)
  }
  # Add max(dataset_column_input) if higher than max(non_empty_breaks)
  if (max(dataset_column_input) > max(non_empty_breaks)) {
    non_empty_breaks[non_empty_breaks == max(non_empty_breaks)] <- max(dataset_column_input)
  }
  non_empty_breaks <- sort(unique(non_empty_breaks))
  print(non_empty_breaks)
  return(non_empty_breaks)}

# DEFINE Function to create bbox: 
create_bbox <- function(dataset_input, justXmin, justXmax, justYmin, justYmax) {
  bbox_new <- st_bbox(dataset_input)
  xrange <- bbox_new$xmax - bbox_new$xmin # range of x values
  yrange <- bbox_new$ymax - bbox_new$ymin # range of y values
  bbox_new[1] <- (bbox_new[1] - (justXmin * xrange)) # xmin - left
  bbox_new[3] <- bbox_new[3] + (justXmax * xrange) # xmax - right
  bbox_new[2] <- bbox_new[2] - (justYmin * yrange) # ymin - bottom
  bbox_new[4] <- bbox_new[4] + (justYmax * yrange) # ymax - top
  bbox_new <- bbox_new %>%  # take the bounding box ...
    st_as_sfc() # ... and make it a sf polygon
  return(bbox_new)}


###DATA: 

## 1) POPULATION AT NUTS
#Get NUTS3 shapes using eurostat
nuts3_all <- get_eurostat_geospatial(
  output_class = "sf",
  resolution = "01",
  nuts_level = "3",
  year = "2016",
  crs = "3035"
)

# Filter the dataset where CNTR_CODE == "FI"
nuts3_FI <- nuts3_all %>% #Simple feature collection with 11 features and 11 fields
  filter(CNTR_CODE == "FI")

## Get Eurostat population table
#freq: #unique(poptable$freq) "A" 
#sex: #unique(poptable$sex) "F" "M" "T"
#unit #unique(poptable$unit) "NR" :number;unitOfMeasure
#age #unique(poptable$age) "TOTAL"  "UNK"    "Y10-14" "Y15-19"...
#geo #unique(poptable$geo) 
#TIME_PERIOD: 2018-01-01 
#values: population 
poptable <- get_eurostat("demo_r_pjangrp3") %>%  
  filter(TIME_PERIOD == "2018-01-01",
         nchar(geo)==5, 
         sex == "T",
         age == "TOTAL")

#Get NUTS3 pop for only FI: 
poptable_FI <- poptable[grep("^FI", poptable$geo), ]

## Get target data: NUTS3 population spatial data through merge: 
nuts3pop <- nuts3_FI %>%
  left_join(poptable_FI, by = c("NUTS_ID" = "geo")) 
#NUTS_ID is NUTS ID in the gisco spatial dataset
#geo is NUTS ID in the Eurostat table

# Set spatial extent FI
analysis_spatial_extent_FI <- st_union(nuts3_FI)

## 2) LAU POP 2018  
#full Europe
LAUpop2018 <- st_read("data/LAU_RG_01M_2018_3035.shp")
#Clip LAU pop using computed extents
LAUpop2018 <- st_intersection(LAUpop2018, analysis_spatial_extent_FI)
#Check geometries
st_geometry_type(LAUpop2018)
# Keep only POLYGON and MULTIPOLYGON geometries
LAUpop2018 <- LAUpop2018[st_geometry_type(LAUpop2018) %in% c("POLYGON", "MULTIPOLYGON"), ]
LAUpop2018 <- st_collection_extract(LAUpop2018, "POLYGON")
LAUpop2018 <- st_cast(LAUpop2018, "MULTIPOLYGON")
# Rename ID column in cor_detailed to avoid duplicates after intersection
colnames(LAUpop2018)[colnames(LAUpop2018) == "FID"] <- "Fid_lookup"
st_write(LAUpop2018, "data/LAUpop2018_FI.gpkg", layer="LAUpop2018FI")

## 3) CORINE land cover 2018: 
# CORINE selection to use: 
# >= 1% contribution to population density according to census grid mapping
corine_list <- c("112", 
                 "121", 
                 "122", 
                 "123",
                 "133",
                 "141") 
# CORINE input: 
cor2018 <- st_read("data/cor2018_FI.gpkg")
# Get corine class names: 
corineexplain <- st_read("inputs/corine_classes.csv", options = "DELIMITER=;") #for corine legend

# Add CORINE land cover class names
cor_names <- cor2018 %>%
  left_join(corineexplain, by = c("Code_18" = "code_18"))

# Only pick certain subset of classes from corine data: 
cor2018_subset <- cor_names[cor_names$Code_18 %in% corine_list,]

# 4) Import weight table
weightTable <- st_read("inputs/cor_weights_FI_overall.csv", options = "DELIMITER=,")


############## DASYMETRIC REFINEMENT ANALYSIS: 

# new AREA COLUMN: calculate NUTS area in km2:
nuts3pop$area_nuts <- set_units((st_area(nuts3pop)), km^2)
# new DENSITY COLUMN: calculate overall population density per Ha for each nuts:  
nuts3pop$dens2018 <- nuts3pop$values / (nuts3pop$area_nuts) 

# Merge the CSV input weight data with the spatial corine object
cor_detailed <- cor2018_subset %>%
  left_join(weightTable, by = c("Code_18" = "Code_18"))

# Rename ID column in cor_detailed to avoid duplicates after intersection
colnames(cor_detailed)[colnames(cor_detailed) == "ID"] <- "cor_id"

# Calculate intersection of residential corine and nuts population (first intersection): 
nuts_cor_intersect <- st_intersection(cor_detailed, nuts3pop)
# Convert percentage from string to numeric: 
nuts_cor_intersect$percentdistribution <- as.numeric(nuts_cor_intersect$percentdistribution)

# new ID column
nuts_cor_intersect$nuts_cor_id <- interaction(nuts_cor_intersect$NUTS_ID, nuts_cor_intersect$Code_18)

# Get unique corine weights per NUTS ID
table_unique_weights <- nuts_cor_intersect %>%
  as_tibble() %>% #to get it as a table and not a spatial output
  select(nuts_cor_id, NUTS_ID, percentdistribution) %>%
  mutate(percentdistribution = as.numeric(percentdistribution)) %>%
  group_by(nuts_cor_id) %>%
  summarize(percUnique = first(percentdistribution), 
            NUTS_ID = first(NUTS_ID)) 

# Sum weights per NUTS ID
table_sum_of_weights <- table_unique_weights %>%
  select(NUTS_ID, percUnique) %>%
  group_by(NUTS_ID) %>%
  summarize(percSum = sum(percUnique)) 

# Merge the sum of weight data with the nuts data
nuts_cor_weights <- nuts_cor_intersect %>%
  left_join(table_sum_of_weights, by = "NUTS_ID")

# new AREA COLUMN: calculate intersection area in km2:
nuts_cor_weights$area_cor <- set_units((st_area(nuts_cor_weights)), km^2)

# Sum area per corine category per NUTS ID (necessary if multiple polygons for same corine category is present in a nuts):
table_area_corine <- nuts_cor_weights %>%
  as_tibble() %>% #to get it as a table and not a spatial output
  select(nuts_cor_id, area_cor) %>%
  mutate(area_cor = as.numeric(area_cor)) %>%
  group_by(nuts_cor_id) %>%
  summarize(area_corSum = sum(area_cor)) 

# Merge overall corine category per nuts area data with the nuts data
nuts_cor_new <- nuts_cor_weights %>%
  left_join(table_area_corine, by = "nuts_cor_id")

# estimated final corine category weight:
nuts_cor_new$newWeight <- (as.numeric(nuts_cor_new$percentdistribution) / #specific corine weight
                             nuts_cor_new$percSum * # sum of all corine weights present in that nuts
                             100.) #percentage

# Get unique normalised corine weights per NUTS ID
table_unique_norm_weights <- nuts_cor_new %>%
  as_tibble() %>% #to get it as a table and not a spatial output
  select(nuts_cor_id, NUTS_ID, newWeight) %>%
  group_by(nuts_cor_id) %>%
  summarize(newWeightUnique = first(newWeight), 
            NUTS_ID = first(NUTS_ID)) 

# Sum normalised weights per NUTS ID
table_sum_of_norm_weights <- table_unique_norm_weights %>%
  select(NUTS_ID, newWeightUnique) %>%
  group_by(NUTS_ID) %>%
  summarize(newWeightSum = sum(newWeightUnique)) 

# Merge the sum of normalised weight data with the nuts data
nuts_cor_norm <- nuts_cor_new %>%
  left_join(table_sum_of_norm_weights, by = "NUTS_ID")

#new column with corine area multiplied the normalised corine weight (draft area-based weights):  
nuts_cor_norm$areaWeight <- nuts_cor_norm$newWeight * nuts_cor_norm$area_cor

# Get sum of area-based weights for each nuts 
table_area_weights <- nuts_cor_norm %>%
  as_tibble() %>% #to get it as a table and not a spatial output
  select(NUTS_ID, areaWeight) %>%
  group_by(NUTS_ID) %>%
  summarize(areaWeightSum = sum(areaWeight)) 

# Merge the area-based weights data with the pop data
nuts_cor_final <- nuts_cor_norm %>%
  left_join(table_area_weights, by = "NUTS_ID")

# New column with full area-based weights:  
nuts_cor_final$areaWeightFull <- nuts_cor_final$areaWeight / nuts_cor_final$areaWeightSum 

# New column with estimated population per corine polygon:  
nuts_cor_final$estPopCor <- as.numeric(nuts_cor_final$values) * as.numeric(nuts_cor_final$areaWeightFull)

###### AREA INTERPOLATION ######
# new ID column to create unique id (some corine categories are divided by nuts borders)
nuts_cor_final$id_cor2 <- interaction(nuts_cor_final$NUTS_ID, nuts_cor_final$cor_id)

# aw_interpolate to interpolate to LAU level: 
estimated_lau_pop <- aw_interpolate(
  .data = LAUpop2018, #referred to as target elsewhere
  tid = "LAU_ID", #id column in target
  source = nuts_cor_final,
  sid = "id_cor2", #id column in source
  weight = "sum", #should be sum for intensive vs. extensive interpolations
  output = "sf",
  extensive = "estPopCor" #attribute in source to interpolate 
)

# replace NA with 0 in estimated pop
estimated_lau_pop$estPopCor[is.na(estimated_lau_pop$estPopCor)] <- 0

# Calculate percentage overestimation (marked with plus) or underestimation (marked with minus) of estimated population 
estimated_lau_pop$pop2018dif <- ((-(estimated_lau_pop$POP_2018 - as.numeric(estimated_lau_pop$estPopCor)) / estimated_lau_pop$POP_2018) *100.)

#Check geometries
st_geometry_type(estimated_lau_pop)
# Keep only POLYGON and MULTIPOLYGON geometries
estimated_lau_pop <- estimated_lau_pop[st_geometry_type(estimated_lau_pop) %in% c("POLYGON", "MULTIPOLYGON"), ]
estimated_lau_pop <- st_collection_extract(estimated_lau_pop, "POLYGON")
estimated_lau_pop <- st_cast(estimated_lau_pop, "MULTIPOLYGON")

#### MAP OUTPUT: ERRORS FOR DASYMETRIC REFINEMENT WITH DANISH WEIGHTS FOR DENMARK 
# Create a new column with absolute values before plotting
estimated_lau_pop$pop2018dif_abs <- abs(estimated_lau_pop$pop2018dif)
# Specify final classification and colors 
rounded_breaks <- c(0, 5, 10, 15, 20, 30, 50, 60, 70, 80, 90, ceiling(max(estimated_lau_pop$pop2018dif_abs)))
final_colors <- c("white", "#f7fbff", "#deebf7", "#B2DDFC", "#9ecae1","#6baed6", "#2171b5","#084594", "#8734ba", "#5e1989", "#450d68", "#170324") #"#c6dbef",#"#4292c6", 
color_mapping <- setNames(final_colors, rounded_breaks)
# TMAP: Over and underestimation of population    
# Bbox of main map: 
bbox_main <- create_bbox(estimated_lau_pop, 0.3, 0.5, 0., 0.15)
# Plot Denmark without Bornholm:
map_percDif_main <- tm_shape(estimated_lau_pop, bbox = bbox_main) + 
  tm_polygons(col = "pop2018dif_abs", 
              title = "Errors in %",
              breaks = rounded_breaks, 
              palette = color_mapping, 
              border.col = "transparent") + 
  tm_layout(bg.color = "#E1EEF2",
            legend.position = c("right", "top"),
            legend.bg.color = "white",
            title= "Weighted area interpolation\nfor Finland with\nFinnish weights",
            legend.title.size = 1.,
            title.position = c("left", "top"),
            legend.frame = "grey60") + 
  tm_compass(type = "arrow", 
             position = c("right", "bottom")) + 
  tm_scale_bar(position = c("right", "bottom"), 
               text.size = 0.8) 
print(map_percDif_main)

# KEY DENSITY COLUMN: estimated LAU population density in km2:  
estimated_lau_pop$densKm2Est <- as.numeric(estimated_lau_pop$estPopCor) / estimated_lau_pop$AREA_KM2 

#### MAP OUTPUT: DASYMETRIC REFINEMENT WITH DANISH WEIGHTS FOR DENMARK 
#quantile_not_rounded: 
rounded_breaks <- c(0.1607, 2.4310, 4.2450, 6.5650, 9.7220, 13.2070, 23.0210, 54.4330, 3047.7270)
# breakvalues: Replace with min if lower than min(rounded_breaks)
if (min(estimated_lau_pop$densKm2Est) < min(rounded_breaks)) {
  rounded_breaks[[1]] <- min(estimated_lau_pop$densKm2Est)
}
# Add max if higher than max(rounded_breaks)
if (max(estimated_lau_pop$densKm2Est) > max(rounded_breaks)) {
  rounded_breaks[[length(rounded_breaks)]] <- max(estimated_lau_pop$densKm2Est)
}
# TMAP: Estimated population density    
# Bbox of main map: 
bbox_main <- create_bbox(estimated_lau_pop, 0.3, 0.5, 0., 0.15)
# Plot Denmark without Bornholm:
map_DensEst_main <- tm_shape(estimated_lau_pop, bbox = bbox_main) +
  tm_polygons(col = "densKm2Est", 
              title = "People per km2\n(2018, estimated)",
              breaks = rounded_breaks, 
              palette = c("#FDFD63", "#990000"), 
              border.col = "transparent") + 
  tm_layout(bg.color = "#E1EEF2",
            legend.position = c("right", "top"),
            legend.bg.color = "white",
            title= "Weighted area interpolation\nfor Finland with\nFinnish weights",
            legend.title.size = 1.,
            title.position = c("left", "top"),
            legend.frame = "grey60") + 
  tm_compass(type = "arrow", 
             position = c("right", "bottom")) + 
  tm_scale_bar(position = c("right", "bottom"), 
               text.size = 0.8)
print(map_DensEst_main)


############## PRINT STATEMENTS ##############
######---------> PRINT
cat("Overall percentage error:", sum(abs(estimated_lau_pop$pop2018dif)))
cat("Overall percentage error average:", sum(estimated_lau_pop$pop2018dif))
cat("Mean signed deviation or Bias:", bias(estimated_lau_pop$POP_2018, as.numeric(estimated_lau_pop$estPopCor)))
cat("Mean absolute error:", mae(estimated_lau_pop$POP_2018, as.numeric(estimated_lau_pop$estPopCor)))
cat("Median absolute error:", mdae(estimated_lau_pop$POP_2018, as.numeric(estimated_lau_pop$estPopCor)))
cat("Mean squared error:", mse(estimated_lau_pop$POP_2018, as.numeric(estimated_lau_pop$estPopCor)))
cat("Root mean squared error:", rmse(estimated_lau_pop$POP_2018, as.numeric(estimated_lau_pop$estPopCor)))
cat("Mean absolute percentage error:", mape(estimated_lau_pop$POP_2018, as.numeric(estimated_lau_pop$estPopCor)))