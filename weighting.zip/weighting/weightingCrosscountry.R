# This code calculate inputs weights for Denmark and Finland cross-country 

# Install and import libraries: 
##install.packages("eurostat")
library(eurostat)
##install.packages("dplyr")
library(dplyr)
##install.packages("mapview")
library(mapview)
##install.packages("rstudioapi")
library(rstudioapi)
##install.packages("sf")
library(sf)

# Set directory to script directory: 
script_directory <- dirname(rstudioapi::getSourceEditorContext()$path)
setwd(script_directory)

# Set proper visualisation of numeric values
options(scipen = 100, digits = 4) # can be reset by options(scipen=0)

# Avoid switching to darkmatter basemap but keep default lightgrey basemap when plotting: 
mapviewOptions(basemaps.color.shuffle = FALSE)

#Take time: 
time_start_processing <- Sys.time() 


###DATA: 

## 1) POPULATION AT NUTS
#Get NUTS3 shapes using eurostat
nuts3_all <- get_eurostat_geospatial(
  output_class = "sf",
  resolution = "01",
  nuts_level = "3",
  year = "2016",
  crs = "3035"
)

# Filter the dataset where CNTR_CODE == "DK"
nuts3_DK <- nuts3_all %>% #Simple feature collection with 11 features and 11 fields
  filter(CNTR_CODE == "DK")
# Filter the dataset where CNTR_CODE == "FI"
nuts3_FI <- nuts3_all %>% #Simple feature collection with 19 features and 11 fields
  filter(CNTR_CODE == "FI")
# Combine DK and FI
nuts3 <- rbind(nuts3_DK, nuts3_FI) #Simple feature collection with 30 features and 11 fields

## Get Eurostat population table
#freq: #unique(poptable$freq) "A" 
#sex: #unique(poptable$sex) "F" "M" "T"
#unit #unique(poptable$unit) "NR" :number;unitOfMeasure
#age #unique(poptable$age) "TOTAL"  "UNK"    "Y10-14" "Y15-19"...
#geo #unique(poptable$geo) 
#TIME_PERIOD: 2018-01-01 
#values: population 
poptable <- get_eurostat("demo_r_pjangrp3") %>%  
  filter(TIME_PERIOD == "2018-01-01",
         nchar(geo)==5, 
         sex == "T",
         age == "TOTAL")

#Get NUTS3 pop for both DK and FI: 
poptable <- poptable[grep("^DK|FI", poptable$geo), ]

## Get target data: NUTS3 population DK spatial data through merge: 
nuts3pop <- nuts3 %>%
  left_join(poptable, by = c("NUTS_ID" = "geo")) 
#NUTS_ID is NUTS ID in the gisco spatial dataset
#geo is NUTS ID in the Eurostat table


## 2) CENSUS GRID 
census_grid_DK <- st_read("data/census_grid_DK.gpkg")
census_grid_FI <- st_read("data/census_grid_FI.gpkg")
census_grid <- rbind(census_grid_DK, census_grid_FI)


## 3) CORINE LAND COVER: 
cor2018_DK <- st_read("data/cor2018_DK.gpkg")
cor2018_FI <- st_read("data/cor2018_FI.gpkg")
cor2018 <- rbind(cor2018_DK, cor2018_FI)


###CALCULATE THE WEIGHTING:

# Interpolate T(=population) and LAND_SURFACE(=area): 
time_start_processing <- Sys.time() 
mapped_pop_corine <- aw_interpolate(
  .data = cor2018, #referred to as target elsewhere
  tid = "ID", #id column in target
  source = census_grid,
  sid = "GRD_ID", #id column in source
  weight = "sum", #should be sum for intensive vs. extensive interpolations
  output = "sf",
  extensive = c("T", "LAND_SURFACE") #attribute in source to interpolate 
)
time_finish_processing <- Sys.time() # Only for measuring computation time
compute_time = difftime(time_finish_processing, time_start_processing, units = "secs")
print(compute_time) #7017 secs #=117 min

# Write file
st_write(mapped_pop_corine, "processdata/intersect_result_crosscountry.gpkg", layer="mappedpopcorineDKFI")

# Aggregate statistics: 
time_start_processing <- Sys.time() 
# Calculate people per CORINE category and area per CORINE category 
aggregated_People <- aggregate(T ~ Code_18, mapped_pop_corine, FUN = sum)
aggregated_Area <- aggregate(LAND_SURFACE ~ Code_18, mapped_pop_corine, FUN = sum)
time_finish_processing <- Sys.time() # Only for measuring computation time
compute_time = difftime(time_finish_processing, time_start_processing, units = "secs")
print(compute_time)

# Join the two aggregated tables together
time_start_processing <- Sys.time() 
joined_data <- full_join(aggregated_People, aggregated_Area, by = "Code_18")
time_finish_processing <- Sys.time() # Only for measuring computation time
compute_time = difftime(time_finish_processing, time_start_processing, units = "secs")
print(compute_time)

# Calculate people density per each corine category:
joined_data$density <- joined_data$T/joined_data$LAND_SURFACE
# Calculate percent density for each corine category: 
joined_data$percentdistribution <- joined_data$density/sum(joined_data$density)*100

# Write table to textfile: 
write.csv(joined_data, file = "weights/cor_weights_DKFIoverall.csv", row.names = TRUE, quote = FALSE)
print("file written")
