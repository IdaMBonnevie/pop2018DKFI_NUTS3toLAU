# This code plots the individual population densities behind the inputs weights for Finland based on Finnish extent  

# Install and import libraries: 
##install.packages("eurostat")
library(eurostat)
##install.packages("dplyr")
library(dplyr)
##install.packages("rstudioapi")
library(rstudioapi)
##install.packages("sf")
library(sf)

# Set directory to script directory: 
script_directory <- dirname(rstudioapi::getSourceEditorContext()$path)
setwd(script_directory)

# Set proper visualisation of numeric values
options(scipen = 100, digits = 4) # can be reset by options(scipen=0)


###FUNCTIONS: 

## create list of corine-census-grid intersects for the corine categories that have a input weight (percentdistribution) >= 1 
create_subsets <- function(weights_df, mapped_df) {
  # Filter Code_18 values where percentdistribution >= 1
  selected_codes <- weights_df$Code_18[weights_df$percentdistribution >= 1]
  # Create a list to store subsets
  subsets_list <- list()
  # Loop through selected Code_18 values
  for (code in selected_codes) {
    subset_name <- paste0("mapped_pop_corine_DKcor", code)
    subsets_list[[subset_name]] <- mapped_df[mapped_df$Code_18 == code, ]
  }
  return(subsets_list)
}

## create scatter plots of each population density for spepcific intersect polygon as a function of polygon size  
plot_scatter_for_subset <- function(subset_data, code) {
  code <- substr(code, nchar(code) - 2, nchar(code))  # Keep only the last 3 characters
  # Define output filename
  output_file <- paste0("CORINEcode_FIoutputs/scatter_plot_", code, ".png")
  # Open a PNG device to save the plot
  png(output_file, width = 800, height = 600, res = 150)  # Set desired size and resolution
  # Plot the scatter plot for LAND_SURFACE vs densCorPolint
  plot(subset_data$LAND_SURFACE, subset_data$densCorPolint, 
       main = paste("Scatter Plot for", code), 
       xlab = "Area in ha", 
       ylab = "Population density per ha", 
       col = "blue", 
       pch = 19) # Use solid circles for points
  # Close the PNG device to save the plot
  dev.off()
}

## create scatter plots of each population density for each intersect polygon as a function of polygon size  
# Now, loop through the subsets and call the function for each one:
plot_all_subsets <- function(subsets_list) {
  # Loop through each subset in the subsets_list
  for (subset_name in names(subsets_list)) {
    subset_data <- subsets_list[[subset_name]]
    # Extract the code from the subset name (assuming it follows the format "mapped_pop_corine_FIcor<code>")
    code <- gsub("mapped_pop_corine_FIcor", "", subset_name)
    # Call the plot function for each subset
    plot_scatter_for_subset(subset_data, code)
  }
}


###DATA: 

# 1) INTERSECTED CENSUS GRID AND CORINE: 
# import intersection. 
mapped_pop_corine_FI <- st_read("processdata/intersect_result_FI.gpkg", layer="mapped_pop_corine_FI")
# Density per individual CORINE polygon:  
mapped_pop_corine_FI$densCorPol <- mapped_pop_corine_FI$T / mapped_pop_corine_FI$LAND_SURFACE 
# replace NA with 0 in estimated pop
mapped_pop_corine_FI$densCorPol[is.na(mapped_pop_corine_FI$densCorPol)] <- 0
# round to integers
mapped_pop_corine_FI$densCorPolint <- round(mapped_pop_corine_FI$densCorPol, 0) 
# remove inf
mapped_pop_corine_FI <- mapped_pop_corine_FI[is.finite(mapped_pop_corine_FI$densCorPolint), ]

# 2) Get weights
weightsFI_FI <- st_read("weights/cor_weights_FI_overall.csv", options = "DELIMITER=,")


###ANALYSIS 1: POPULATION DENSITIES FOR INPUT WEIGHTS 

# create subsets of corine classes that have percentdistribution >= 1 
subsets <- create_subsets(weightsFI_FI, mapped_pop_corine_FI)

# Check if the folder exists, and create it if it doesn't
subfolder <- "CORINEcode_FIoutputs"
if (!dir.exists(subfolder)) {
  dir.create(subfolder)
}

# Scatter plots
plot_all_subsets(subsets)
