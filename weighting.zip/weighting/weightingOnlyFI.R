# This code calculate inputs weights for Denmark based on Finnish extent  

# Install and import libraries: 
##install.packages("eurostat")
library(eurostat)
##install.packages("dplyr")
library(dplyr)
##install.packages("mapview")
library(mapview)
##install.packages("rstudioapi")
library(rstudioapi)
##install.packages("sf")
library(sf)

# Set directory to script directory: 
script_directory <- dirname(rstudioapi::getSourceEditorContext()$path)
setwd(script_directory)

# Set proper visualisation of numeric values
options(scipen = 100, digits = 4) # can be reset by options(scipen=0)

# Avoid switching to darkmatter basemap but keep default lightgrey basemap when plotting: 
mapviewOptions(basemaps.color.shuffle = FALSE)


###DATA: 

## 1) POPULATION AT NUTS
#Get NUTS3 shapes using eurostat
nuts3_all <- get_eurostat_geospatial(
  output_class = "sf",
  resolution = "01",
  nuts_level = "3",
  year = "2016",
  crs = "3035"
)

# Filter the dataset where CNTR_CODE == "FI"
nuts3_FI <- nuts3_all %>% #Simple feature collection with 19 features and 11 fields
  filter(CNTR_CODE == "FI")

## Get Eurostat population table
#freq: #unique(poptable$freq) "A" 
#sex: #unique(poptable$sex) "F" "M" "T"
#unit #unique(poptable$unit) "NR" :number;unitOfMeasure
#age #unique(poptable$age) "TOTAL"  "UNK"    "Y10-14" "Y15-19"...
#geo #unique(poptable$geo) 
#TIME_PERIOD: 2018-01-01 
#values: population 
poptable <- get_eurostat("demo_r_pjangrp3") %>%  
  filter(TIME_PERIOD == "2018-01-01",
         nchar(geo)==5, 
         sex == "T",
         age == "TOTAL")

#Get NUTS3 pop for only FI: 
poptable_FI <- poptable_all[grep("^FI", poptable_all$geo), ]

# Combine DK and FI
#poptable <- rbind(poptable_DK, poptable_FI)


## Get target data: NUTS3 population spatial data through merge: 
nuts3pop_FI <- nuts3_FI %>%
  left_join(poptable_FI, by = c("NUTS_ID" = "geo")) 
#NUTS_ID is NUTS ID in the gisco spatial dataset
#geo is NUTS ID in the Eurostat table


## ---------- SET SPATIAL EXTENT (NOT NECESSARY TO RUN)
# Set spatial extent FI
#analysis_spatial_extent_FI <- st_union(nuts3_FI)
## ---------- 


## 2) CENSUS GRID 
## ---------- Census grid from the full European dataset (NOT NECESSARY TO RUN)
# #census_grid_all <- st_read("data/ESTAT_Census_2021_V2.gpkg") #onlyOneLayer
# time_start_processing <- Sys.time() 
# census_grid_FI <- st_intersection(census_grid_FI, analysis_spatial_extent_FI)
# time_finish_processing <- Sys.time() # Only for measuring computation time
# compute_time = difftime(time_finish_processing, time_start_processing, units = "secs")
# print(compute_time)
# # Write file
# st_write(census_grid_FI, "data/census_grid_FI.gpkg", layer="census_grid_FI")
## ---------- 
## CENSUS GRID (to be run)
census_grid_FI <- st_read("data/census_grid_FI.gpkg")


## 3) CORINE LAND COVER: 
## ---------- Corine land cover from the full European dataset (NOT NECESSARY TO RUN)
# Path to corine GeoPackage
#cor2018_all_path <- "data/U2018_CLC2018_V2020_20u1.gpkg"
# List all layers in the corine GeoPackage
#corlayers <- st_layers(cor2018_all_path)$name
#Filter layers that end with "_20u1"
#cor2018_layer <- corlayers[grepl("_20u1$", corlayers)]
# time_start_processing <- Sys.time() 
# cor2018_FI <- st_intersection(cor2018_layer, analysis_spatial_extent_DK)
# time_finish_processing <- Sys.time() # Only for measuring computation time
# compute_time = difftime(time_finish_processing, time_start_processing, units = "secs")
# print(compute_time)
# # Write file
# st_write(cor2018_FI, "data/cor2018_FI.gpkg", layer="cor2018_FI")
## ---------- 
cor2018_FI <- st_read("data/cor2018_FI.gpkg")


###CALCULATE THE WEIGHTING:

# Interpolate T(=population) and LAND_SURFACE(=area): 
time_start_processing <- Sys.time() 
mapped_pop_corine_FI <- aw_interpolate(
  .data = cor2018_FI, #referred to as target elsewhere
  tid = "ID", #id column in target
  source = census_grid_FI,
  sid = "GRD_ID", #id column in source
  weight = "sum", #should be sum for intensive vs. extensive interpolations
  output = "sf",
  extensive = c("T", "LAND_SURFACE") #attribute in source to interpolate 
)
time_finish_processing <- Sys.time() # Only for measuring computation time
compute_time = difftime(time_finish_processing, time_start_processing, units = "secs")
print(compute_time) 

# Write file
st_write(mapped_pop_corine_FI, "processdata/intersect_result_FI.gpkg", layer="mapped_pop_corine_FI")

# Aggregate statistics: 
time_start_processing <- Sys.time() 
# Calculate people per CORINE category and area per CORINE category 
aggregated_People_FI <- aggregate(T ~ Code_18, mapped_pop_corine_FI, FUN = sum)
aggregated_Area_FI <- aggregate(LAND_SURFACE ~ Code_18, mapped_pop_corine_FI, FUN = sum)
time_finish_processing <- Sys.time() # Only for measuring computation time
compute_time = difftime(time_finish_processing, time_start_processing, units = "secs")
print(compute_time)

# Join the two aggregated tables together
time_start_processing <- Sys.time() 
joined_data_FI <- full_join(aggregated_People_FI, aggregated_Area_FI, by = "Code_18")
time_finish_processing <- Sys.time() # Only for measuring computation time
compute_time = difftime(time_finish_processing, time_start_processing, units = "secs")
print(compute_time)

# Calculate people density per each corine category:
joined_data_FI$density <- joined_data_FI$T/joined_data_FI$LAND_SURFACE
# Calculate percent density for each corine category: 
joined_data_FI$percentdistribution <- joined_data_FI$density/sum(joined_data_FI$density)*100

# Write table to textfile: 
write.csv(joined_data_FI, file = "weights/cor_weights_FI_overall.csv", row.names = TRUE, quote = FALSE)
print("file written")





