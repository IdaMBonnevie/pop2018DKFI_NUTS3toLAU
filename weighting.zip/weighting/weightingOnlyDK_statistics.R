# This code plots the individual population densities behind the inputs weights for Denmark based on Danish extent  
# it additionally investigates statistics based on the overlap with Danish 2018 residential square meters 

# Install and import libraries: 
##install.packages("areal")
library(areal)
##install.packages("eurostat")
library(eurostat)
##install.packages("dplyr")
library(dplyr)
##install.packages("openxlsx")
library(openxlsx)
##install.packages("rstudioapi")
library(rstudioapi)
##install.packages("sf")
library(sf)
##install.packages("tmap")
library(tmap)

# Set directory to script directory: 
script_directory <- dirname(rstudioapi::getSourceEditorContext()$path)
setwd(script_directory)

# Set proper visualisation of numeric values
options(scipen = 100, digits = 4) # can be reset by options(scipen=0)


###FUNCTIONS: 

## create list of corine-census-grid intersects for the corine categories that have a input weight (percentdistribution) >= 1 
create_subsets <- function(weights_df, mapped_df) {
  # Filter Code_18 values where percentdistribution >= 1
  selected_codes <- weights_df$Code_18[weights_df$percentdistribution >= 1]
  # Create a list to store subsets
  subsets_list <- list()
  # Loop through selected Code_18 values
  for (code in selected_codes) {
    subset_name <- paste0("mapped_pop_corine_DKcor", code)
    subsets_list[[subset_name]] <- mapped_df[mapped_df$Code_18 == code, ]
  }
  return(subsets_list)
}

## create scatter plots of each population density for spepcific intersect polygon as a function of polygon size  
plot_scatter_for_subset <- function(subset_data, code) {
  code <- substr(code, nchar(code) - 2, nchar(code))  # Keep only the last 3 characters
  # Define output filename
  output_file <- paste0("CORINEcode_DKoutputs/scatter_plot_", code, ".png")
  # Open a PNG device to save the plot
  png(output_file, width = 800, height = 600, res = 150)  # Set desired size and resolution
  # Plot the scatter plot for LAND_SURFACE vs densCorPolint
  plot(subset_data$LAND_SURFACE, subset_data$densCorPolint, 
       main = paste("Scatter Plot for", code), 
       xlab = "Area in ha", 
       ylab = "Population density per ha", 
       col = "blue", 
       pch = 19) # Use solid circles for points
  # Close the PNG device to save the plot
  dev.off()
}

## create scatter plots of each population density for each intersect polygon as a function of polygon size  
# Now, loop through the subsets and call the function for each one:
plot_all_subsets <- function(subsets_list) {
  # Loop through each subset in the subsets_list
  for (subset_name in names(subsets_list)) {
    subset_data <- subsets_list[[subset_name]]
    # Extract the code from the subset name (assuming it follows the format "mapped_pop_corine_DKcor<code>")
    code <- gsub("mapped_pop_corine_DKcor", "", subset_name)
    # Call the plot function for each subset
    plot_scatter_for_subset(subset_data, code)
  }
}

## Large functions to get statistics based on Danish residential square meters (BBR): 
statistics_cor_bbr <- function(subsets_list, census_grid_DK, bbr2017_subset) {
  # Check if the folder exists, and create it if it doesn't
  subfolder <- "bbrDK_statistics"
  if (!dir.exists(subfolder)) {
    dir.create(subfolder)
  }
  # Loop through each subset in the subsets_list
  for (subset_name in names(subsets_list)) {
    subset_data <- subsets_list[[subset_name]]
    # Extract the code from the subset name (assuming it follows the format "mapped_pop_corine_DKcor<code>")
    code <- gsub("mapped_pop_corine_DKcor", "", subset_name)
    # get subsets of polygons for each census grid cell
    DKcorsubpolygons <- st_intersection(subset_data, census_grid_DK) 
    # select some columns 
    DKcorsubpolygons_subset <- DKcorsubpolygons %>%
      select(Code_18, 
             Area_Ha_fp = Area_Ha, 
             ID_fp = ID, 
             LAND_SURFACE_fp = LAND_SURFACE, 
             T_fp = T, 
             densCorPol_fp = densCorPol,
             densCorPolint_fp = densCorPolint,
             geom) %>%
      mutate(new_ID_sp = row_number())  # Add unique ID column
    # get the correct people (T) and area (LAND_SURFACE) for each subpolygon
    mapped_DKcorcensus <- aw_interpolate(
      .data = DKcorsubpolygons_subset, #referred to as target elsewhere
      tid = "new_ID_sp", #id column in target
      source = subset_data,
      sid = "ID", #id column in source
      weight = "sum", #should be sum for intensive vs. extensive interpolations
      output = "sf",
      extensive = c("T", "LAND_SURFACE") #attribute in source to interpolate 
    )
    # summarise building squaremeters per polygonpart 
    #buildings_polygons <- st_join(bbr2017_subset, mapped_DKcorcensus, join = st_within)
    buildings_polygons <- st_intersection(bbr2017_subset, mapped_DKcorcensus)
    polygon_sqm_summary <- buildings_polygons %>%
      group_by(new_ID_sp) %>%  # Replace "polygon_id" with the actual column name in your polygon dataset
      summarise(total_sqm = sum(byg039BygningensSamlBoligAreal), na.rm = TRUE)  # Replace "square_meters" with the actual column name in your dataset
    # join back to main table
    mapped_DKcorcensus_stat_df <- mapped_DKcorcensus %>% st_drop_geometry()
    mapped_DKcorcensus_stat <- mapped_DKcorcensus_stat_df %>%
      left_join(polygon_sqm_summary, by = "new_ID_sp") 
    # Restore the original geometry
    st_geometry(mapped_DKcorcensus_stat) <- st_geometry(mapped_DKcorcensus)
    #map squaremeters
    mapped_DKcorcensus_stat <- st_as_sf(mapped_DKcorcensus_stat)
    mapped_DKcorcensus_stat$total_sqm[is.na(mapped_DKcorcensus_stat$total_sqm)] <- 0
    mapped_DKcorcensus_stat$T[is.na(mapped_DKcorcensus_stat$T)] <- 0
    mapped_DKcorcensus_stat$SqmPrPop <- mapped_DKcorcensus_stat$total_sqm/mapped_DKcorcensus_stat$T
    # Define LAND_SURFACE bins
    mapped_DKcorcensus_stat2 <- mapped_DKcorcensus_stat %>%
      mutate(LAND_SURFACE_bin = cut(LAND_SURFACE, 
                                    breaks = c(0.0, 0.2, 0.4, 0.6, 0.8, 1.0), 
                                    labels = c("0.0-0.2", "0.2-0.4", "0.4-0.6", "0.6-0.8", "0.8-1"),
                                    include.lowest = TRUE))
    # Count occurrences of popPrSqm ≤ 0.03 and > 0.03 per LAND_SURFACE bin
    mapped_DKcorcensus_stat2_df <- mapped_DKcorcensus_stat2 %>% st_drop_geometry()
    summary_table <- mapped_DKcorcensus_stat2_df %>%
      group_by(LAND_SURFACE_bin) %>%
      summarise(count_more_eq_30M2PrPGood = sum(SqmPrPop >= 30., na.rm = TRUE), #good
                count_less_30M2PrPBad = sum(SqmPrPop < 30., na.rm = TRUE), #bad
                total = n())
    # higher perc is good as people have enough average m2 for it to be realistic
    summary_table$goodperc <- summary_table$count_more_eq_30M2PrPGood / summary_table$total * 100.
    file_path <- "bbrDK_statistics/statistics_cor_bbr.xlsx"
    print("looking at first file")
    # Check if the file exists
    if (!file.exists(file_path)) {
      wb <- createWorkbook()
      addWorksheet(wb, code)
      # Write the dataframe to an Excel file
      writeData(wb, code, summary_table)
      saveWorkbook(wb, file_path, overwrite = FALSE)
    } else {
      wb <- loadWorkbook(file_path)  # Load the existing file
      addWorksheet(wb, code)  # Add a new sheet
      writeData(wb, code, summary_table)  # Write data to the new sheet
      saveWorkbook(wb, file_path, overwrite = TRUE)  # Save changes
    }
    # Get polygons from mapped_DKcor121census that did not join with any bbr2017_subset points
    polygons_not_buildings <- mapped_DKcorcensus %>%
      filter(!new_ID_sp %in% buildings_polygons$new_ID_sp)
    #population 
    polygons_not_buildings$T[is.na(polygons_not_buildings$T)] <- 0 
    #plot pop pr m2
    polygons_not_buildings$LAND_SURFACE[is.na(polygons_not_buildings$LAND_SURFACE)] <- 0
    plot(polygons_not_buildings$LAND_SURFACE, polygons_not_buildings$T)
    # Define LAND_SURFACE bins
    polygons_not_buildings2 <- polygons_not_buildings %>%
      mutate(LAND_SURFACE_bin = cut(LAND_SURFACE, 
                                    breaks = c(0.0, 0.2, 0.4, 0.6, 0.8, 1.0), 
                                    labels = c("0.0-0.2", "0.2-0.4", "0.4-0.6", "0.6-0.8", "0.8-1"),
                                    include.lowest = TRUE))
    # Count occurrences of pop per LAND_SURFACE bin
    polygons_not_buildings2_df <- polygons_not_buildings2 %>% st_drop_geometry()
    summary_table_no_bbr <- polygons_not_buildings2_df %>%
      group_by(LAND_SURFACE_bin) %>%
      summarise(count_People = n(),
                sum_People = sum(T, na.rm = TRUE), 
                av_People = sum_People/count_People)
    file2_path <- "bbrDK_statistics/statistics_cor_nobbr.xlsx"
    print("looking at second file")
    # Check if the file exists
    if (!file.exists(file2_path)) {
      wb2 <- createWorkbook()
      addWorksheet(wb2, code)
      # Write the dataframe to an Excel file
      writeData(wb2, code, summary_table_no_bbr)
      saveWorkbook(wb2, file2_path, overwrite = FALSE)
    } else {
      wb2 <- loadWorkbook(file2_path)  # Load the existing file
      addWorksheet(wb2, code)  # Add a new sheet
      writeData(wb2, code, summary_table_no_bbr)  # Write data to the new sheet
      saveWorkbook(wb2, file2_path, overwrite = TRUE)  # Save changes
    }
    polygons_with_buildings <- mapped_DKcorcensus %>%
      filter(new_ID_sp %in% buildings_polygons$new_ID_sp)
    st_write(polygons_with_buildings, 
             paste0("bbrDK_statistics/polygons_with_buildings", code, ".gpkg"),
             layer=paste0("polygons_with_buildings", code)) 
    st_write(polygons_not_buildings, 
             paste0("bbrDK_statistics/polygons_not_buildings", code, ".gpkg"),
             layer=paste0("polygons_not_buildings", code)) 
    st_write(buildings_polygons, 
             paste0("bbrDK_statistics/bbr", code, ".gpkg"),
             layer=paste0("bbr", code)) 
    
    
  }
}


###DATA: 

# 1) INTERSECTED CENSUS GRID AND CORINE: 
# import intersection. 
mapped_pop_corine_DK <- st_read("processdata/intersect_result_DK.gpkg", layer="mapped_pop_corine_DK")
# Density per individual CORINE polygon:  
mapped_pop_corine_DK$densCorPol <- mapped_pop_corine_DK$T / mapped_pop_corine_DK$LAND_SURFACE 
# replace NA with 0 in estimated pop
mapped_pop_corine_DK$densCorPol[is.na(mapped_pop_corine_DK$densCorPol)] <- 0
# round to integers
mapped_pop_corine_DK$densCorPolint <- round(mapped_pop_corine_DK$densCorPol, 0) 
# remove inf
mapped_pop_corine_DK <- mapped_pop_corine_DK[is.finite(mapped_pop_corine_DK$densCorPolint), ]

# 2) Get weights
weightsDK_DK <- st_read("weights/cor_weights_DK_overall.csv", options = "DELIMITER=,")

# 3) Get census grid
census_grid_DK <- st_read("data/census_grid_DK.gpkg", layer="census_grid_DK")

# 4) Get BBR
bbr2017 <- st_read("data/bbr2017.gpkg", layer="bbr2017oldest")



###ANALYSIS 1: POPULATION DENSITIES FOR INPUT WEIGHTS 

# create subsets of corine classes that have percentdistribution >= 1 
subsets <- create_subsets(weightsDK_DK, mapped_pop_corine_DK)

# Check if the folder exists, and create it if it doesn't
subfolder <- "CORINEcode_DKoutputs"
if (!dir.exists(subfolder)) {
  dir.create(subfolder)
}

# Scatter plots
plot_all_subsets(subsets)


###ANALYSIS 2: DANISH BUILDING DATASET (BBR) TO INVESTIGATE INPUT WEIGHT INTERSECT POLYGON OVERLAPS WITH 2018 RESIDENTIAL SQUARE METERS  

# Create a new BBR dataset with only selected columns
bbr2017_subset <- bbr2017 %>% # BBR with construction year <= 2017 
  select(BygningId, 
         byg021BygningensAnvendelse, 
         byg021BygningensAnvendelse_T, 
         byg026OpFoerelsesAar, 
         byg027OmTilBygningsAar, 
         byg039BygningensSamlBoligAreal, 
         geom)

# Calculate BBR statistics gathered in a new subfolder called bbrDK_statistics
statistics_cor_bbr(subsets, census_grid_DK, bbr2017_subset)
